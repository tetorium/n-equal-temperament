# n-equal-temperament
This is a self-made patch by max / MSP for composing n equal temperament music. Use with Logic Pro X. You are free to use it, but if it is used, please state that you are using my own patch. Also, if you would like to contact me, please contact my Twitter DM. twitter:TETO@network_chord
